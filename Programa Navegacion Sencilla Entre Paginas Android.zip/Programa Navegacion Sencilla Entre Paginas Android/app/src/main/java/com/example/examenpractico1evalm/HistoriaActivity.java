package com.example.examenpractico1evalm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class HistoriaActivity extends AppCompatActivity {
    private ImageButton historialogo;
    private Button historiagrupo;
    private Button historiadiscos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.historia);

        historialogo = findViewById(R.id.historialogo);
        historiagrupo = findViewById(R.id.historiagrupo);
        historiadiscos = findViewById(R.id.historiadiscos);

    }


    public void historiagrupo (View view)
    {
        Intent historiagrupo = new Intent(this, GrupoActivity.class);
        startActivity(historiagrupo);
    }

    public void historiadiscos (View view)
    {
        Intent historiadiscos = new Intent(this, DISCOSActivity.class);
        startActivity(historiadiscos);
    }

    public void volver (View view)
    {
        Intent volver = new Intent(this, PrincipalActivity.class);
        startActivity(volver);
    }
}