package com.example.examenpractico1evalm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class DISCOSActivity extends AppCompatActivity {

    private ImageButton discoslogo;
    private Button discoshistoria;
    private Button discosgrupo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.discos);

        discoslogo = findViewById(R.id.discoslogo);
        discoshistoria = findViewById(R.id.discoshistoria);
        discosgrupo = findViewById(R.id.discosgrupo);


    }

    public void discoshistoria(View view) {
        Intent discoshistoria = new Intent(this, HistoriaActivity.class);
        startActivity(discoshistoria);
    }

    public void discosgrupo(View view) {
        Intent discosgrupo = new Intent(this, GrupoActivity.class);
        startActivity(discosgrupo);
    }


    public void volver(View view) {
        Intent volver = new Intent(this, PrincipalActivity.class);
        startActivity(volver);
    }
}