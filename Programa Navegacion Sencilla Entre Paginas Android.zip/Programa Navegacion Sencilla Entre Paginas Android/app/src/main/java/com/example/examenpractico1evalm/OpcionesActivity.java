package com.example.examenpractico1evalm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class OpcionesActivity extends AppCompatActivity {

    private ImageButton opcioneslogo;
    private Button opcioneshistoria;
    private Button opcionesgrupo;
    private Button opcionesdiscos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.opciones);

        opcioneslogo = findViewById(R.id.opcioneslogo);
        opcioneshistoria = findViewById(R.id.opcioneshistoria);
        opcionesgrupo = findViewById(R.id.opcionesgrupo);
        opcionesdiscos = findViewById(R.id.opcionesdiscos);

    }

    public void opcioneshistoria (View view)
    {
        Intent opcioneshistoria = new Intent(this, HistoriaActivity.class);
        startActivity(opcioneshistoria);
    }

    public void opcionesgrupo (View view)
    {
        Intent opcionesgrupo = new Intent(this, GrupoActivity.class);
        startActivity(opcionesgrupo);
    }

    public void opcionesdiscos (View view)
    {
        Intent opcionesdiscos = new Intent(this, DISCOSActivity.class);
        startActivity(opcionesdiscos);
    }

    public void volver (View view)
    {
        Intent volver = new Intent(this, PrincipalActivity.class);
        startActivity(volver);
    }

}
