package com.example.examenpractico1evalm;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;


public class PrincipalActivity extends AppCompatActivity {
    private Button entrar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal);

        entrar = findViewById(R.id.entrar);


    }

    public void entrar (View view)
    {
        Intent entrar = new Intent(this, OpcionesActivity.class);
        startActivity(entrar);
    }


}