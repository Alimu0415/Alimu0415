package com.example.examenpractico1evalm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class GrupoActivity extends AppCompatActivity {

    private ImageButton grupologo;
    private Button grupohistoria;
    private Button grupodiscos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.grupo);

        grupologo = findViewById(R.id.grupologo);
        grupohistoria = findViewById(R.id.grupohistoria);
        grupodiscos = findViewById(R.id.grupodiscos);

    }

    public void grupohistoria(View view) {
        Intent grupohistoria = new Intent(this, HistoriaActivity.class);
        startActivity(grupohistoria);
    }


    public void grupodiscos(View view) {
        Intent grupodiscos = new Intent(this, DISCOSActivity.class);
        startActivity(grupodiscos);
    }

    public void volver(View view) {
        Intent volver = new Intent(this, PrincipalActivity.class);
        startActivity(volver);
    }
}