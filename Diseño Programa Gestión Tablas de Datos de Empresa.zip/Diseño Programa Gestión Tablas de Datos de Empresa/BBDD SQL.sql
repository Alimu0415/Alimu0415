DROP DATABASE IF EXISTS empresa; 
CREATE DATABASE empresa; 
USE empresa; 
 
CREATE TABLE proveedores ( 
    nif_pro VARCHAR(9) PRIMARY KEY, 
    nom_pro VARCHAR(40), 
    dir_pro VARCHAR(40), 
    tlf_pro VARCHAR(12), 
    ema_pro VARCHAR(40), 
    dto_pro DECIMAL(5,2) 
); 
 
 
CREATE TABLE clientes ( 
    dni_cli VARCHAR(9) PRIMARY KEY, 
    nom_cli VARCHAR(40), 
    dir_cli VARCHAR(40), 
    tlf_cli VARCHAR(12), 
    ema_cli VARCHAR(40), 
    dto_cli DECIMAL(5,2) 
); 
 
CREATE TABLE empleados ( 
    dni_emp VARCHAR(9) PRIMARY KEY, 
    nom_emp VARCHAR(40), 
	dir_emp VARCHAR(40), 
	tlf_emp VARCHAR(12), 
    ema_emp VARCHAR(40), 
    pue_emp ENUM('compras', 'direccion', 'contabilidad', 'produccion', 'diseño', 'transporte') 
    ); 
 
 
CREATE TABLE articulos ( 
    ide_art INT AUTO_INCREMENT PRIMARY KEY, 
nom_art VARCHAR(30),     
tip_art ENUM('terminado', 'materia'), 
    imp_art DECIMAL(5,2), 
    sto_art INT(5) 
); 
 
 
CREATE TABLE factura_venta ( 
    num_ven INT AUTO_INCREMENT PRIMARY KEY, 
    fec_ven DATE, 
    tot_ven DECIMAL(7,2), 
    dni_emp VARCHAR(9), 
    dni_cli VARCHAR(9), 
    FOREIGN KEY (dni_emp) REFERENCES empleados(dni_emp), 
    FOREIGN KEY (dni_cli) REFERENCES clientes(dni_cli) 
); 
 
 
CREATE TABLE factura_compra ( 
    num_com INT AUTO_INCREMENT PRIMARY KEY, 
	fac_com VARCHAR (20), 
    fec_com DATE, 
    tot_com DECIMAL(7,2), 
    dni_emp VARCHAR(9), 
    nif_pro VARCHAR(9),  
    FOREIGN KEY (dni_emp) REFERENCES empleados(dni_emp), 
    FOREIGN KEY (nif_pro) REFERENCES proveedores(nif_pro) 
); 
 
 
CREATE TABLE detalle_venta ( 
    ide_dve INT AUTO_INCREMENT PRIMARY KEY, 
     can_dve INT(4),    
 imp_dve DECIMAL(7,2), 
     ide_art INT, 
    num_ven INT, 
    FOREIGN KEY (ide_art) REFERENCES articulos(ide_art), 
    FOREIGN KEY (num_ven) REFERENCES factura_venta(num_ven) 
); 
 
 
CREATE TABLE detalle_compra ( 
    ide_dco INT AUTO_INCREMENT PRIMARY KEY, 
    can_dco INT(4), 
    imp_dco DECIMAL(7,2), 
    ide_art INT, 
    num_com INT, 
    FOREIGN KEY (ide_art) REFERENCES articulos(ide_art), 
    FOREIGN KEY (num_com) REFERENCES factura_compra(num_com) 
); 

