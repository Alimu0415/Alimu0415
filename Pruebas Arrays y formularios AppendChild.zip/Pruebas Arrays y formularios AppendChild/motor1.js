    // Estructura original del formulario
    const titulo = document.createElement("h1");
    titulo.innerHTML = "Ejercicio 1";
    document.body.appendChild(titulo);

// Array
document.addEventListener("DOMContentLoaded", function() {
    const numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

//Mostrar
    const divnumeros = document.createElement("div");
    divnumeros.innerHTML = "Contenido del array: " + numeros.join(" ");

    document.body.appendChild(divnumeros);

        function mostrarNumeros(array) {
            console.log(array);
        }

        mostrarNumeros(numeros);

// Sumar
function calcularSuma(array) {
    let recorridosuma = 0;

    for (let i = 0; i < array.length; i++) {
        recorridosuma = recorridosuma + array[i];
    }

    console.log("La suma de los números es: " + recorridosuma);
}

calcularSuma(numeros);

// Mayor 
    function encontrarMayor (array) {

        let recorridomayor = 0;

        for (let i = 1; i < array.length; i++) {

            if (array[i] > recorridomayor) {
                recorridomayor = array[i];
            }
        }
        console.log("El número más grande es: " + recorridomayor);
    }

    encontrarMayor(numeros);

// Pares
 function filtrarPares(array) {
    const pares = array.filter(function(num) {
        return num % 2 === 0; 
    });
    console.log("Numeros pares: " + pares);
}
filtrarPares(numeros);

// Multiplicar
    function multiplicarPor(array, multiplicador) {
        let recorridomultiplicar = []; 

        for (let i = 0; i < array.length; i++) {
            recorridomultiplicar[i] = array[i] * multiplicador; 
        }

        return recorridomultiplicar; 
    }

    const multiplicadosya = multiplicarPor(numeros, 4);  // Multiplico por 4 por ejemplo

    console.log("Multiplicaciones por 4: " +multiplicadosya);

// Orden Ascendente


  function ordenarAscendente(array) {

    // COPIA
    let copiaarrayordenada = array.slice();
    
    // UTILIZO UN ARRAY TEMPORAL PARA SUSTITUIR LOS DATOS A FUTURO PARA NO PERDER EL VALOR E IMPRIMIRLO BIEN
    for (let i = 0; i < copiaarrayordenada.length; i++) {
        for (let j = i + 1; j < copiaarrayordenada.length; j++) {

            if (copiaarrayordenada[i] > copiaarrayordenada[j]) {
                let temporal = copiaarrayordenada[i];
                copiaarrayordenada[i] = copiaarrayordenada[j];
                copiaarrayordenada[j] = temporal;
            }
        }
    }

    // RECORREN EL ARRAY HASTA ENCONTRAR UN VALOR MAYOR Y SE COLOCAN TRAS ESTE
    
    console.log("Ordenados en ascendente: " + copiaarrayordenada);
}

ordenarAscendente(numeros);

});


