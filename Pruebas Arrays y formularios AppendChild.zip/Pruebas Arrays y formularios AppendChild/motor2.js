window.onload = function() {

        // Estructura original del formulario
        const titulo = document.createElement("h1");
        titulo.innerHTML = "Ejercicio 2";
        document.body.appendChild(titulo);

    const contenedorPrincipal = document.createElement("div");
    contenedorPrincipal.id = "contenedorPrincipal";
    document.body.appendChild(contenedorPrincipal);

    const divAgregar = document.createElement("div");
    divAgregar.id = "divAgregar";
    const labelNombre = document.createElement("label");
    labelNombre.id = "labelNombre";
    labelNombre.innerHTML = "Nombre:";
    const inputNombre = document.createElement("input");
    inputNombre.id = "inputNombre";
    const labelEdad = document.createElement("label");
    labelEdad.id = "labelEdad";
    labelEdad.innerHTML = "Edad:";
    const inputEdad = document.createElement("input");
    inputEdad.id = "inputEdad";
    inputEdad.type = "number";
    inputEdad.min = "1";
    const botonAgregar = document.createElement("button");
    botonAgregar.innerHTML = "Agregar";

    divAgregar.appendChild(labelNombre);
    divAgregar.appendChild(inputNombre);
    divAgregar.appendChild(labelEdad);
    divAgregar.appendChild(inputEdad);
    divAgregar.appendChild(botonAgregar);
    
    document.body.appendChild(divAgregar);




    const divEliminar = document.createElement("div");
    divEliminar.id = "divEliminar";

    const labelEliminar = document.createElement("label");
    labelEliminar.id = "labelEliminar";
    labelEliminar.innerHTML = "Índice para eliminar:";
    const InputEliminar = document.createElement("input");
    InputEliminar.id = "InputEliminar";
    const botonEliminar = document.createElement("button");
    botonEliminar.innerHTML = "Eliminar";

    divEliminar.appendChild(labelEliminar);
    divEliminar.appendChild(InputEliminar);
    divEliminar.appendChild(botonEliminar);
    document.body.appendChild(divEliminar);



    const divActualizar = document.createElement("div");
    divActualizar.id = "divActualizar";
    const LabelActualizar = document.createElement("label");
    LabelActualizar.id = "LabelActualizar";
    LabelActualizar.innerHTML = "Índice para actualizar:";
    const InputActualizar = document.createElement("input");
    InputActualizar.id = "InputActualizar";
    const labelNombreActualizar = document.createElement("label");
    labelNombreActualizar.id = "labelNombreActualizar";
    labelNombreActualizar.innerHTML = "Nuevo nombre:";
    const inputNombreActualizar = document.createElement("input");
    inputNombreActualizar.id = "inputNombreActualizar";
    const labelEdadActualizar = document.createElement("label");
    labelEdadActualizar.id = "labelEdadActualizar";
    labelEdadActualizar.innerHTML = "Nueva edad:";
    const inputEdadActualizar = document.createElement("input");
    inputEdadActualizar.id = "inputEdadActualizar";
    inputEdadActualizar.type = "number";
    inputEdadActualizar.min = "1";
    const botonActualizar = document.createElement("button");
    botonActualizar.innerHTML = "Actualizar";

    divActualizar.appendChild(LabelActualizar);
    divActualizar.appendChild(InputActualizar);
    divActualizar.appendChild(labelNombreActualizar);
    divActualizar.appendChild(inputNombreActualizar);
    divActualizar.appendChild(labelEdadActualizar);
    divActualizar.appendChild(inputEdadActualizar);
    divActualizar.appendChild(botonActualizar);
    document.body.appendChild(divActualizar);




    const divContar = document.createElement("div");
    divContar.id = "divContar";
    const botonContar = document.createElement("button");
    botonContar.innerHTML = "Contar";
    divContar.appendChild(botonContar);
    document.body.appendChild(divContar);



    const InformacionUL = document.createElement("ul");
    InformacionUL.id = "InformacionUL";
    document.body.appendChild(InformacionUL);




    function agregarElemento() {
        const nombre = inputNombre.value;
        const edad = inputEdad.value;

        if (!nombre || !edad) {
            alert("Agrega nombre y edad, por favor");
            return;
        }

        const li = document.createElement("li");
        // AQUI SOLO ME DEJA CON ` Y NO CON ""
        li.innerHTML = `Nombre: ${nombre}, Edad: ${edad}`;

        InformacionUL.appendChild(li);

    }

    botonAgregar.addEventListener("click", agregarElemento);



    function eliminarElemento() {
        const index = InputEliminar.value;

        const elementos = InformacionUL.getElementsByTagName("li");
        if (index >= 0 && index < elementos.length) {
            InformacionUL.removeChild(elementos[index]);
        } else {
            alert("Majo, no hay elemento que puedas eliminar en esta posición");
        }
    }

    botonEliminar.addEventListener("click", eliminarElemento);


    function actualizarContenido() {
        const index = InputActualizar.value;
        const nuevoNombre = inputNombreActualizar.value;
        const nuevaEdad = inputEdadActualizar.value;

        const elementos = InformacionUL.getElementsByTagName("li");
        if (index >= 0 && index < elementos.length) {
            if (!nuevoNombre || !nuevaEdad) {
                alert("Termina por rellenar los campos de Actualización");
                return;
            }

 // AQUI TAMPOCO ME DEJA USAR "", SOLO CON `
            elementos[index].innerHTML = `Nombre: ${nuevoNombre}, Edad: ${nuevaEdad}`;
        } else {
            alert("Índice inválido.");
        }
    }

    botonActualizar.addEventListener("click", actualizarContenido);



    function contarElementos() {
        const elementos = InformacionUL.getElementsByTagName("li");
        const total = elementos.length;

        // AQUI IGUAL, TAMPOCO ME DEJA USAR "", SOLO CON `
        alert(`Cantidad total de elementos: ${total}`);
    }

    botonContar.addEventListener("click", contarElementos);

};

// NO SE SI USAR MUCHO EL getElementsByTagName ES UNA MALA PRAXIS, PERO YA NO ENCONTRABA OTRA FORMA DE HACERLO Y ME ESTABA ESTRESANDO, BUEN DIA SARA
