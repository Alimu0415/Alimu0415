document.addEventListener("DOMContentLoaded", () => {

    const titulo = document.createElement("h1");
    titulo.innerHTML = "Ejercicio 3";
    document.body.appendChild(titulo);

    const divformulario = document.createElement("div");
    divformulario.id = "divformulario";
    document.body.appendChild(divformulario);

    const divmensaje  = document.createElement("div");
    divmensaje.id = "divmensaje";
    document.body.appendChild(divmensaje);

    const formulario = document.createElement("form");
    formulario.id = "formulario";

    const labelNelementos = document.createElement("label");
    labelNelementos.innerHTML = "Ingrese el número de elementos: ";
    const inputNelementos = document.createElement("input");
    inputNelementos.type = "number";
    inputNelementos.id = "Numero";
    inputNelementos.min = 1;
    inputNelementos.required = true;

    const labelTelementos = document.createElement("label");
    labelTelementos.innerHTML = "Ingrese el tipo de elementos: 1:div, 2:p, 3:span, 4:imagen"
    const inputTelementos = document.createElement("input");
    inputTelementos.type = "number";
    inputTelementos.id = "Tipo";
    inputTelementos.min = 1;
    inputTelementos.max = 4;
    inputTelementos.required = true;

    const labelpintarcss1 = document.createElement("label");
    labelpintarcss1.innerHTML = "Opciones de background-color: 1:Rojo, 2:Amarillo, 3:Verde";
    const inputpintarcss1 = document.createElement("input");
    inputpintarcss1.type = "number";
    inputpintarcss1.id = "CSS1";
    inputpintarcss1.min = 1;
    inputpintarcss1.max = 3;
    inputpintarcss1.required = true;

    const labelpintarcss2 = document.createElement("label");
    labelpintarcss2.innerHTML = "Opciones de border-radius: 1:Verde, 2:Azul, 3:Morado";
    const inputpintarcss2 = document.createElement("input");
    inputpintarcss2.type = "number";
    inputpintarcss2.id = "CSS2";
    inputpintarcss2.min = 1;
    inputpintarcss2.max = 3;
    inputpintarcss2.required = true;

    const botonCrear = document.createElement("button");
    botonCrear.type = "submit";
    botonCrear.textContent = "Crear";

    formulario.appendChild(labelNelementos);
    formulario.appendChild(inputNelementos);
    formulario.appendChild(labelTelementos);
    formulario.appendChild(inputTelementos);
    formulario.appendChild(labelpintarcss1);
    formulario.appendChild(inputpintarcss1);
    formulario.appendChild(labelpintarcss2);
    formulario.appendChild(inputpintarcss2);
    formulario.appendChild(botonCrear);

    divformulario.appendChild(formulario);

    const formularioEliminar = document.createElement("form");

    const labelEliminar = document.createElement("label");
    labelEliminar.textContent = "¿Qué elemento quieres eliminar?";
    const inputEliminar = document.createElement("input");
    inputEliminar.type = "number";
    inputEliminar.id = "Eliminar";
    inputEliminar.min = 0;
    inputEliminar.required = true;

    const botonEliminar = document.createElement("button");
    botonEliminar.type = "submit";
    botonEliminar.innerHTML = "Eliminar";

    formularioEliminar.appendChild(labelEliminar);
    formularioEliminar.appendChild(inputEliminar);
    formularioEliminar.appendChild(botonEliminar);

    divformulario.appendChild(formularioEliminar);

    formulario.addEventListener("submit", (event) => {
        event.preventDefault();

        const numero = parseInt(inputNelementos.value);
        const tipo = parseInt(inputTelementos.value);
        const css1 = parseInt(inputpintarcss1.value);
        const css2 = parseInt(inputpintarcss2.value);

        let tipoElemento;

        if (tipo === 1) {
            tipoElemento = "div";
        } else if (tipo === 2) {
            tipoElemento = "p";
        } else if (tipo === 3) {
            tipoElemento = "span";
        } else if (tipo === 4) {
            tipoElemento = "img";
        } else {
            alert("Solo valores del 1 al 4, por favor");
            return;
        }

        let backgroundColor;
        let borderColor;


        if (css1 === 1) {
            backgroundColor = "red";
        } else if (css1 === 2) {
            backgroundColor = "yellow";
        } else if (css1 === 3) {
            backgroundColor = "green";
        } else {
            alert("Solo valores del 1 al 3, por favor");
            return;
        }


        if (css2 === 1) {
            borderColor = "green";
        } else if (css2 === 2) {
            borderColor = "blue";
        } else if (css2 === 3) {
            borderColor = "purple";
        } else {
            alert("Solo valores del 1 al 3, por favor");
            return;
        }

        for (let i = 0; i < numero; i++) {
            const elemento = document.createElement(tipoElemento);
            elemento.style.backgroundColor = backgroundColor;
            elemento.style.border = `2px solid ${borderColor}`; //SOLO ME DEJA CON `, NO CON ""


            if (tipoElemento === "p") {
                elemento.textContent = "p";
            } else if (tipoElemento === "span") {
                elemento.textContent = "span";
            } else if (tipoElemento === "div") {
                elemento.style.width = "200px";
                elemento.style.height = "200px";
            } else if (tipoElemento === "img") {
                elemento.src = "bombilla.png";
                elemento.style.width = "200px";
                elemento.style.height = "200px";
            }

            divmensaje.appendChild(elemento);
        }
    });


    formularioEliminar.addEventListener("submit", (event) => {
        event.preventDefault();

        const index = parseInt(inputEliminar.value);
        const elementos = divmensaje.children;
        
        if (index >= 0 && index < elementos.length) {
            divmensaje.removeChild(elementos[index]);
        } else {
            alert("No existe ningún elemento con este valor: " + "mínimo: 0 " + "máximo: " + (elementos.length - 1));
        }
    });
});

// SE ME OLVIDO PONER LAS FUNCIONES, LO HE HECHO CON ADDEVENTLISTENER, DISCULPA:
//Funcion crearElemento (recibe parametro tipo elemento a crear)
// Funcion pintarElemento dibuja elementos que se crean en punto anterior
// Funcion css elemento
// Funcion borrarElemento preguntar elminar elemento teclear si pide la etiqueta en cuestion se elimina el nodo